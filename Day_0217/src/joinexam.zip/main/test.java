package joinexam.main;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String email = "asdf123@naver123.com";
		System.out.println(email.matches("[a-zA-Z0-9]*@[a-zA-Z0-9]*\\.[a-zA-Z0-9]{2,3}"));
	}

}
